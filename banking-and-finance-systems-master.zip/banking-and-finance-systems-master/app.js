const express = require('express');
const path = require('path');
const Register = require('./models/register');
const app = express();

const hostname='localhost';
const port = 4200;

app.use(express.static(__dirname +'/public'));

app.get("/", (req,res) =>{
    res.render("index")
});

app.get("/register", (req,res)=> {
    res.render("register")
});

app.post("/register",async (req,res) =>{
    try{
        console.log(req.body.firstname);
        res.send(req.body.firstname);
        const password = req.body.password;
        const cpassword = req.body.Confirmpassword;
        if(password==cpassword){
            const registerBank = new Register({
                name:req.body.name,
                username:req.body.uname,
                age:req.body.age,
                gender:req.body.gender,
                phone:req.body.phone,
                email:req.body.email,
                password:req.body.password,
                confirmpassword:req.body.confirmpassword,
            })
            const registered = await registerBank.save();
            res.status(201).render(index);
        
        }
        else{
            res.send("password are not matching");
        }
    }catch(error){
        res.status(400).send(error);
    }

});
app.get("/login", (req,res)=>{
    res.render("login")
});
server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });