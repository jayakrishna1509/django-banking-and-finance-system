const mongoose = require("mongoose");

const BankSchema = new mongoose.Mongoose.Schema({
    Name:
    {
        type:String,
        required:true
    },
    Username:
    {
        type:String,
        required:true
    },
    Age:
    {
        type:Number,
        required:true
    },
    Gender:
    {
        type:String,
        required:true
    },
    Phone:
    {
        type:Number,
        required:true,
        unique:true
    },
    Email:
    {
        type:String,
        required:true,
        unique:true
    },
    Password:
    {
        type:Number,
        required:true
    },
    Confirmpassword:
    {
        type:Number,
        required:true,
    }
})

const Register = new mongoose.Mongoose.model("Banking",BankSchema);
module.exports = Register;